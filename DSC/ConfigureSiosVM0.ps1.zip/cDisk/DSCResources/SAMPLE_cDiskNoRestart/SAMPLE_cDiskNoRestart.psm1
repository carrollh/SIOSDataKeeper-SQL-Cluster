#
# xComputer: DSC resource to initialize, partition, and format disks.
#

# Updated to add a paramter to suppress restart

function Get-TargetResource
{
    [OutputType([System.Collections.Hashtable])]
    param
    (
        [parameter(Mandatory)]
        [uint32] $DiskNumber,

        [string] $DriveLetter
    )

    $disk = Get-Disk -Number $DiskNumber
    $returnValue = @{
        DiskNumber = $disk.Index
        DriveLetter = $(Get-CimInstance win32_diskdrive -Filter "DeviceID = '\\\\.\\PHYSICALDRIVE$DiskNumber'" | Get-CimAssociatedInstance -ResultClassName win32_diskpartition | Get-CimAssociatedInstance -ResultClassName win32_logicaldisk).DeviceID[0]
    }
    $returnValue
}

function Set-TargetResource
{
    param
    (
        [parameter(Mandatory)]
        [uint32] $DiskNumber,

        [string] $DriveLetter
    )
    
    $disk = Get-Disk -Number $DiskNumber
    
    $online = "list disk" | diskpart | Where {$_ -match "Disk 2"} | where {$_ -match "Online"}
    if ($online -eq $Null)
    {
        Write-Verbose 'Setting disk Online'
        $dpscript = @"
select disk $DiskNumber
online disk noerr
online disk
convert gpt
create partition primary
assign letter=$DriveLetter
automount enable
create volume simple
format fs=ntfs label="DATA" quick
"@
	$dpscript | diskpart
    }

    $drive = $(Get-CimInstance win32_diskdrive -Filter "DeviceID = '\\\\.\\PHYSICALDRIVE$DiskNumber'" | Get-CimAssociatedInstance -ResultClassName win32_diskpartition | Get-CimAssociatedInstance -ResultClassName win32_logicaldisk).DeviceID
    if($drive -ne $Null -AND $drive[0] -eq $DriveLetter) {
        Write-Host "Successfully mounted volume $DriveLetter"
    }
}

function Test-TargetResource
{
	[OutputType([System.Boolean])]
    param
    (
        [parameter(Mandatory)]
        [uint32] $DiskNumber,

        [string] $DriveLetter
    )

    Write-Verbose "Checking if drive $DriveLetter`: is available on Disk $DiskNumber"
    $drive = $(Get-CimInstance win32_diskdrive -Filter "DeviceID = '\\\\.\\PHYSICALDRIVE$DiskNumber'" | Get-CimAssociatedInstance -ResultClassName win32_diskpartition | Get-CimAssociatedInstance -ResultClassName win32_logicaldisk).DeviceID
    if($drive -ne $Null -AND $drive[0] -eq $DriveLetter) {
        return $true
    }
    return $false
}



function Get-Disk
{
    param
    (
        [parameter(Mandatory)]
        [uint32] $Number
    )
    
    Get-WmiObject Win32_DiskDrive | % { 
        if ($_.index -eq $Number) {
            return $_
        }
    } 

    return $Null
}

Export-ModuleMember -Function *-TargetResource
